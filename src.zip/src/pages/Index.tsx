import ElizaInterface from "@/components/ElizaInterface";

const Index = () => {
  return <ElizaInterface />;
};

export default Index;