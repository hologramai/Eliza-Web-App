import React, { useState, useEffect } from 'react';
import { Volume2, Home, Twitter, Send, Wallet, LogIn } from 'lucide-react';
import './ElizaInterface.css';

interface Message {
  id: string;
  text: string;
  isEliza: boolean;
  timestamp: Date;
}

interface UserStatus {
  messagesUsed: number;
  remainingMessages: number;
  totalMessages: number;
  status: 'anonymous' | 'connected';
}

interface WalletState {
  isConnected: boolean;
  address: string | null;
  isConnecting: boolean;
}

const ElizaInterface = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm Eliza, your AI companion from the neon-lit digital realm. I'm here to listen, support, and chat with you about anything on your mind. How are you feeling today? ✨",
      isEliza: true,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [floatCount, setFloatCount] = useState(0);
  const [shouldFloat, setShouldFloat] = useState(true);
  const [userStatus, setUserStatus] = useState<UserStatus>({
    messagesUsed: 0,
    remainingMessages: 4,
    totalMessages: 4,
    status: 'anonymous'
  });
  const [wallet, setWallet] = useState<WalletState>({
    isConnected: false,
    address: null,
    isConnecting: false
  });

  const API_BASE = 'http://127.0.0.1:5000';

  // Initial floating animation - 3 times
  useEffect(() => {
    const timer = setTimeout(() => {
      setFloatCount(prev => {
        if (prev < 2) {
          return prev + 1;
        } else {
          setShouldFloat(false);
          return prev;
        }
      });
    }, 6000);

    return () => clearTimeout(timer);
  }, [floatCount]);

  // Only check for MetaMask without auto-connecting
  useEffect(() => {
    if (typeof window.ethereum !== 'undefined') {
      console.log('MetaMask detected');
    }
  }, []);

  // Only update user status when wallet is manually connected
  useEffect(() => {
    if (wallet.isConnected && wallet.address) {
      updateUserStatus();
    }
  }, [wallet.address]);

  const connectWallet = async () => {
    if (typeof window.ethereum === 'undefined') {
      console.log('MetaMask is not installed');
      window.open('https://metamask.io/download/', '_blank');
      return;
    }

    setWallet(prev => ({ ...prev, isConnecting: true }));

    try {
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts',
      });

      if (accounts.length > 0) {
        setWallet({
          isConnected: true,
          address: accounts[0],
          isConnecting: false
        });
        console.log('Connected to ' + accounts[0]);
      }
    } catch (error: any) {
      console.error('Failed to connect wallet:', error);
      setWallet(prev => ({ ...prev, isConnecting: false }));
    }
  };

  const disconnectWallet = () => {
    setWallet({
      isConnected: false,
      address: null,
      isConnecting: false
    });
    setUserStatus({
      messagesUsed: 0,
      remainingMessages: 4,
      totalMessages: 4,
      status: 'anonymous'
    });
    console.log('Wallet disconnected');
  };

  const updateUserStatus = async () => {
    if (!wallet.address) return;
    
    try {
      const response = await fetch(API_BASE + '/api/user-status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ wallet: wallet.address }),
      });

      if (response.ok) {
        const status = await response.json();
        setUserStatus(status);
      }
    } catch (error) {
      console.error('Failed to update user status:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isEliza: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputValue;
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch(API_BASE + '/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          wallet: wallet.address,
          message: currentInput,
          chatHistory: messages
        }),
      });

      const data = await response.json();

      if (data.success) {
        const elizaResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: data.response,
          isEliza: true,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, elizaResponse]);

        setUserStatus(prev => ({
          ...prev,
          messagesUsed: data.messagesUsed,
          remainingMessages: data.remainingMessages
        }));

        setIsVoiceActive(true);
        setShouldFloat(true);
        setFloatCount(0);
        
        setTimeout(() => setIsVoiceActive(false), 3000);
        console.log('Message sent. ' + data.messagesUsed + '/' + data.totalMessages + ' used, ' + data.remainingMessages + ' remaining');

      } else {
        console.error('Chat error:', data.error);
        if (data.quota_exceeded) {
          setUserStatus(prev => ({ ...prev, remainingMessages: 0 }));
        }
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getStatusMessage = () => {
    if (!wallet.isConnected) {
      return "💬 Anonymous mode - Connect wallet for personalized experience ✨";
    }
    
    const shortAddress = wallet.address?.slice(0, 6) + '...' + wallet.address?.slice(-4);
    return "🔗 Connected: " + shortAddress + " ✨";
  };

  return (
    <div className="eliza-container">
      <div className="eliza-background"></div>
      <div className="eliza-gradient-overlay"></div>
      <div className="eliza-circuit-overlay"></div>

      <header className="eliza-header">
        <div className="eliza-header-left">
          <button className="eliza-button">
            <Home className="w-6 h-6" />
          </button>
        </div>
        
        <div className="eliza-header-right">
          <div className="eliza-message-counter">
            Messages: {userStatus.messagesUsed}/{userStatus.totalMessages}
          </div>
          
          {!wallet.isConnected ? (
            <button
              onClick={connectWallet}
              disabled={wallet.isConnecting}
              className="eliza-button eliza-wallet-button"
            >
              <Wallet className="w-5 h-5" />
              {wallet.isConnecting ? 'Connecting...' : 'Connect Wallet'}
            </button>
          ) : (
            <button
              onClick={disconnectWallet}
              className="eliza-button eliza-wallet-button"
            >
              <Wallet className="w-5 h-5" />
              {wallet.address?.slice(0, 6) + '...' + wallet.address?.slice(-4)}
            </button>
          )}
          
          <button className="eliza-button">
            <LogIn className="w-6 h-6" />
          </button>
          
          <button
            className="eliza-button"
            onClick={() => window.open('https://twitter.com', '_blank')}
          >
            <Twitter className="w-6 h-6" />
          </button>
          
          <button
            className="eliza-button"
            onClick={() => window.open('https://t.me', '_blank')}
          >
            <Send className="w-6 h-6" />
          </button>
        </div>
      </header>

      <div className="eliza-main">
        <div className="eliza-status">
          <div className="eliza-status-text">
            {getStatusMessage()}
          </div>
        </div>

        <div className="eliza-avatar-container">
          <img
            src="/lovable-uploads/fd3cd33d-bebd-4c6f-9987-bcf664a58e0f.png"
            alt="Eliza AI"
            className={'eliza-avatar' + (shouldFloat && floatCount < 3 ? ' floating' : '')}
          />
          
          <div className="eliza-voice-indicator">
            <Volume2 className={'eliza-voice-icon' + (isVoiceActive ? ' active' : '')} />
            {isVoiceActive && (
              <>
                <div className="eliza-voice-pulse"></div>
                <div className="eliza-voice-pulse delayed"></div>
              </>
            )}
          </div>
        </div>

        <div className="eliza-chat-container">
          <div className="eliza-messages">
            {messages.map((message) => (
              <div
                key={message.id}
                className={'eliza-message-row ' + (message.isEliza ? 'eliza' : 'user')}
              >
                <div className={'eliza-message ' + (message.isEliza ? 'eliza' : 'user')}>
                  <p className="eliza-message-text">{message.text}</p>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="eliza-typing">
                <div className="eliza-typing-bubble">
                  <div className="eliza-typing-dots">
                    <div className="eliza-typing-dot"></div>
                    <div className="eliza-typing-dot"></div>
                    <div className="eliza-typing-dot"></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="eliza-input-section">
            <div className="eliza-input-container">
              <input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Share your thoughts with Eliza..."
                disabled={userStatus.remainingMessages <= 0}
                className="eliza-input"
              />
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isTyping || userStatus.remainingMessages <= 0}
              className="eliza-send-button"
            >
              {isTyping ? 'Sending...' : 'Send'}
            </button>
          </div>

          {userStatus.remainingMessages <= 1 && userStatus.remainingMessages > 0 && (
            <div className="eliza-quota-warning">
              ⚠️ Only {userStatus.remainingMessages} message{userStatus.remainingMessages === 1 ? '' : 's'} remaining!
            </div>
          )}
          
          {userStatus.remainingMessages <= 0 && (
            <div className="eliza-quota-exceeded">
              💳 Message limit reached. Please subscribe to continue chatting with Eliza! ✨
            </div>
          )}
        </div>

        <div className="eliza-footer-left">
          <p>Eliza AI • Always here for you</p>
        </div>
        
        <div className="eliza-footer-right">
          <p>Backend: {API_BASE}</p>
        </div>
      </div>
    </div>
  );
};

export default ElizaInterface;